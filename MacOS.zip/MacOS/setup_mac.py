from setuptools import setup
setup(
    app=["main.py"],
    setup_requires=["py2app"],
)